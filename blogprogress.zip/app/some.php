<?php

// namespace App;

// class Some{
//     function($id, $name) --construct($id){

//     }
// }
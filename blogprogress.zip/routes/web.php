<?php
namespace App\HTTP\Controllers;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/




Route::get('/about', function () {
    return view('welcome');
});

Route::get('/some{id}',[SomeController::class,'getSome']);

Route::get('/main',[MainController::class,'index']);
Route::get('/contacts',[ContactsController::class,'index']);
Route::get('/about',[AboutController::class,'index']);

Route::get('/view',[viewController::class,'index']);
Route::get('/add',[AddController::class,'index']);
Route::post('/addinv',[AddInvController::class,'store'])->name('form.submit');
Route::get('/delete',[DeleteController::class,'index']);
Route::post('/deleteinv',[DeleteInvController::class,'delete'])->name('delete.submit');
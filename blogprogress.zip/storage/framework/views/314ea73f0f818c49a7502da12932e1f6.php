<?php $__env->startSection('content'); ?>
    <div>
    this is about page
    </div>
<?php $__env->stopSection(); ?><?php /**PATH D:\Skins\AdobePNG\For use\Art\Shops\WebDev\laravel\blogprogress\resources\views/about.blade.php ENDPATH**/ ?>
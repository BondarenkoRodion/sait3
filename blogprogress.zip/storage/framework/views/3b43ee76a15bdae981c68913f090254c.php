<?php
namespace App\Http\Controllers;
use App\HTTP\Controllers\PostController;

if (isset($_POST["submit"])) {
    
    $name = $_POST["ProductName"];
    $desc = $_POST["ProductDescription"];
    $id = $_POST["ProductID"];
    $sales = $_POST["ProductSales"];
    PostController::firstOrPost($name,$desc,$id,$sales);

} ?><?php /**PATH D:\Skins\AdobePNG\For use\Art\Shops\WebDev\laravel\blogprogress\resources\views//invisible/add-inv.blade.php ENDPATH**/ ?>
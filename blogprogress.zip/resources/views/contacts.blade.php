@section('content')
    <div>
    Сторінка з контактами!!
    </div>
</div>
</body>
</html>